from django.shortcuts import render, redirect
from .forms import LeaveForm
from .models import Leave
# Create your views here.

from collections import OrderedDict

# Include the `fusioncharts.py` file that contains functions to embed the charts.
from .fusioncharts import FusionCharts
from .forms import DocumentForm


def ml_helper():
    import leave.ml_helper


def add_leave(request):
    if not request.session.get('username', None):
        return redirect('login')
    form = LeaveForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('graph')

    context = {
        'form': form
    }
    return render(request, "leave/leave_form.html", context)


def leave_show(request):
    if not request.session.get('username', None):
        return redirect('login')

    leave = Leave.objects.all()
    context = {
        'leave': leave
    }

    return render(request, "leave/all_leave.html", context)




def hr_analytics(request):
    ml_helper()
    return render(request, 'hr_analytics.html')


def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            documents = form.save(commit=False)
            documents.document.name = 'hr_analytics_new.csv'
            documents.save()
            return redirect('hr_analytics')
    else:
        form = DocumentForm()
    return render(request, 'model_form_upload.html', {
        'form': form
    })


def hr_analytics_result(request):
    return render(request, 'hr_analytics_result.html')
