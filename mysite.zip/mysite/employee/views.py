from django.shortcuts import render,redirect

from .models import addemployee
from .forms import EmpForm
# Create your views here.

def all_emp(request):
    if not request.session.get('username', None):
        return redirect('login')
    emps = addemployee.objects.all()
    context={
        'emps':emps,
    }
    return render(request,"employee/index.html",context)



def dashborad(request):
    if not request.session.get('username', None):
        return redirect('login')

    return render(request,"employee/dashboard.html")

def add_emp(request):
    if not request.session.get('username', None):
        return redirect('login')
    form = EmpForm(request.POST or None)
    if form.is_valid():
        form.save()
        redirect('all_emp')

    context ={
        'form':form
    }

    return render(request,"employee/add_emp.html",context)



def update_emp(request,id):
    if not request.session.get('username', None):
        return redirect('login')
    emps = addemployee.objects.get(id=id)
    form = EmpForm(request.POST or None,instance=emps)
    if form.is_valid():
        form.save()

        return redirect('all_emp')

    context={
        'form':form,
        'emps':emps
    }
    return render(request, 'employee/add_emp.html',context)


def delete_emp(request,id):
    if not request.session.get('username', None):
        return redirect('login')
    emps = addemployee.objects.get(id=id)
    if request.method=='POST':
        emps.delete()
        return redirect('all_emp')


    context={

        'emp': emps
    }
    return render(request, 'employee/confirm_delete.html',context)


def view_emp(request,id):
    if not request.session.get('username', None):
        return redirect('login')
    emps = addemployee.objects.get(id=id)


    context={
       'emps':emps
    }
    return render(request, 'employee/views_details.html',context)

