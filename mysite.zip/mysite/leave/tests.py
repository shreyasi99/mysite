import csv

csv_file = csv.reader(open('HR_comma_sep.csv','r'))


print(csv_file)
lvl = str(input("Enter Value ="))
for i in csv_file:
    print(i)