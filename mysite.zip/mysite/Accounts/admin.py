from django.contrib import admin
from .models import NewUsers
# Register your models here.
admin.site.register(NewUsers)