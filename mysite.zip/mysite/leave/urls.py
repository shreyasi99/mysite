

from django.urls import path

from . import views as leave_views

urlpatterns = [
    path('', leave_views.add_leave,name='leave'),

    path('showLeave/', leave_views.leave_show,name='leave_show'),
    path('analytics/', leave_views.hr_analytics,name='hr_analytics'),
    path('analytics/result', leave_views.hr_analytics_result,name='result'),
    path('upload/', leave_views.model_form_upload,name='model_form_upload'),


]
