#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np

import os
import threading


def handler_task():
    # Build paths inside the project like this: os.path.join(BASE_DIR, ...)
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # # Loading the dataset

    # In[2]:

    hr_df = pd.read_csv(os.path.join(BASE_DIR, 'media/documents/hr_analytics_new.csv'))

    # In[3]:

    hr_df.head()

    # In[4]:

    hr_df.columns

    # # Encoding Categorical Features

    # In[5]:

    numerical_features = ['satisfaction_level', 'last_evaluation', 'number_project',
                          'average_montly_hours', 'time_spend_company']

    # In[6]:

    categorical_features = ['Work_accident', 'left',
                            'promotion_last_5years', 'sales', 'salary']

    # # An utility function to create variable

    # In[7]:

    def create_dummies(df, colname):
        col_dummies = pd.get_dummies(df[colname], prefix=colname)
        col_dummies.drop(col_dummies.columns[0], axis=1, inplace=True)
        df = pd.concat([df, col_dummies], axis=1)
        df.drop(colname, axis=1, inplace=True)
        return df

    # In[8]:

    for c_feature in categorical_features:
        hr_df = create_dummies(hr_df, c_feature)

    # In[9]:

    hr_df.head()

    # # Splitting the dataset

    # In[10]:

    features_columns = hr_df.columns.difference(['left_1'])

    # In[11]:

    features_columns

    # In[13]:

    from sklearn.model_selection import train_test_split

    train_x, test_x, train_y, test_y = train_test_split(hr_df[features_columns],
                                                        hr_df['left_1'],
                                                        test_size=0.2,
                                                        random_state=42)

    # # Building Model

    # # Logistic regression model

    # In[14]:

    from sklearn.linear_model import LogisticRegression

    logreg = LogisticRegression()
    logreg.fit(train_x, train_y)

    # In[15]:

    list(zip(features_columns, logreg.coef_[0]))

    # In[16]:

    logreg.intercept_

    # # Predicting the test cases

    # In[17]:

    hr_test_pred = pd.DataFrame({'actual': test_y,
                                 'predicted': logreg.predict(test_x)})

    # In[18]:

    hr_test_pred = hr_test_pred.reset_index()

    # # Comparing the prediction with actual test data

    # In[19]:

    hr_test_pred.sample(n=10)

    # # Creating a confusion matrix

    # In[20]:

    from sklearn import metrics

    cm = metrics.confusion_matrix(hr_test_pred.actual,
                                  hr_test_pred.predicted, [1, 0])
    cm

    # In[21]:

    import matplotlib.pyplot as plt
    import seaborn as sn

    # get_ipython().run_line_magic('matplotlib', '')

    # In[26]:

    sn.heatmap(cm, annot=True, fmt='.2f', xticklabels=["Left", "No Left"], yticklabels=["Left", "No Left"])
    plt.ylabel('True label')
    plt.xlabel('predicted label')
    plt.savefig('static/heatmap_True_vs_predicted_label.png')
    plt.show()

    # In[27]:

    score = metrics.accuracy_score(hr_test_pred.actual, hr_test_pred.predicted)
    round(float(score), 2)

    # # Observation
    # Overall test accuracy is 78%. But it is not a good measure. The result is very high as there are lots of cases which are no left and the model has predicted most of them as no left.
    #
    # The objective of the model is to indentify the people who will leave, so that the company can intervene and act.
    #
    # This might be the case as the default model assumes people with more than 0.5 probability will not leave the company.

    # # Predict probability
    #

    # In[28]:

    test_x[:1]

    # In[29]:

    logreg.predict_proba(test_x[:1])

    # # Note:
    # The model is predicting the probability of him leaving the company is only 0.027, which is very low.

    # # How good the model is?

    # In[30]:

    predict_proba_df = pd.DataFrame(logreg.predict_proba(test_x))
    predict_proba_df.head()

    # In[31]:

    hr_test_pred = pd.concat([hr_test_pred, predict_proba_df], axis=1)

    # In[32]:

    hr_test_pred.columns = ['index', 'actual', 'predicted', 'Left_0', 'Left_1']

    # In[33]:

    auc_score = metrics.roc_auc_score(hr_test_pred.actual, hr_test_pred.Left_1)
    round(float(auc_score), 2)

    # In[57]:

    sn.distplot(hr_test_pred[hr_test_pred.actual == -1]["Left_1"], color='b')
    sn.distplot(hr_test_pred[hr_test_pred.actual == 0]["Left_1"], color='g')
    # plt.savefig('distplot_Left_1.png')

    svm = sn.distplot(hr_test_pred[hr_test_pred.actual == 0]["Left_1"], color='g')

    figure = svm.get_figure()
    figure.savefig('static/distplot_Left_1.png', dpi=100);

    # # Finding the optimal cutoff probability

    # In[44]:

    fpr, tpr, thresholds = metrics.roc_curve(hr_test_pred.actual,
                                             hr_test_pred.Left_1,
                                             drop_intermediate=False)

    plt.figure(figsize=(6, 4))
    plt.plot(fpr, tpr, label='ROC curve (area = %0.2f)' % auc_score)
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate or [1 - True Negative Rate]')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    plt.savefig('static/ROC_curve.png')
    plt.show()

    # In[45]:

    thresholds[0:10]

    # In[46]:

    fpr[0:10]

    # In[47]:

    tpr[0:10]

    # In[48]:

    cutoff_prob = thresholds[(np.abs(tpr - 0.7)).argmin()]

    # In[49]:

    round(float(cutoff_prob), 2)

    # # Predicting with new cut-off probability



t1 = threading.Thread(target=handler_task)
t1.start()
