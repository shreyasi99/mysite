
from django.urls import path

from . import views as up_views

urlpatterns = [
    path('',up_views.user_proile,name='userprofile')
]
