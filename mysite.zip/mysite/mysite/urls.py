from django.urls import path, include

from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static


from . import views as home_views
urlpatterns = [
      path('admin/', admin.site.urls),
      path('',home_views.index_home, name='main_home'),
      path('about/',home_views.index_about, name='main_about'),
      path('contacts/',home_views.index_contacts, name='main_contacts'),

      path('accounts/', include('Accounts.urls')),
      path('employee/', include('employee.urls')),
      path('leave/', include('leave.urls')),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
