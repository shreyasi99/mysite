from django.db import models


class Category(models.Model):
    name=models.CharField(max_length=20)

    def __str__(self):
        return self.name

class addemployee(models.Model):
    fname = models.CharField(max_length=20)
    mname = models.CharField(max_length=20)
    lname = models.CharField(max_length=20)
    userName = models.CharField(max_length=20, verbose_name='Username', unique=True)
    password = models.CharField(max_length=50, verbose_name='Enter password')
    user_email = models.CharField(max_length=50, verbose_name='Enter email')
    mobile = models.CharField(max_length=20, verbose_name='Enter Mobile no.')
    sex = models.CharField(max_length=50, verbose_name='Gender')
    dob = models.CharField(max_length=50, verbose_name='Date of Birth',default='dd-mm-yyyy')
    nationality = models.CharField(max_length=50, verbose_name='nationality')
    address = models.TextField( verbose_name='Address')
    category = models.ForeignKey(Category, on_delete=models.CASCADE)

    def __str__(self):
        return self.fname


