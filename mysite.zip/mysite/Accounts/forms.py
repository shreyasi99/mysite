from django import forms
from . models import NewUsers
class UserForm(forms.ModelForm):
    class Meta:
        model = NewUsers
        fields = '__all__'


class LoginForm(forms.Form):

    username = forms.CharField(max_length=40,
                             label="Username",
                             widget=forms.TextInput(
                                 attrs = {
                                     'class' : 'form-control',
                                     'placeholder':'Username'
                                }))

    password = forms.CharField(max_length=40,
                            label="Password",
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Enter Password'
                                }))

class ChangePassword(forms.ModelForm):

    class Meta:
        model = NewUsers
        fields = ['password']

    password = forms.CharField(max_length=40,
                            label="Old Password",
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Old Password'
                                }))
    newPassword = forms.CharField(max_length=40,
                                     label="New Password",
                                     widget=forms.TextInput(
                                         attrs={
                                             'class': 'form-control',
                                             'placeholder': 'New Password'
                                         }))
    repeatPassword = forms.CharField(max_length=40,
                                  label="Repeat Password",
                                  widget=forms.TextInput(
                                      attrs={
                                          'class': 'form-control',
                                          'placeholder': 'Repeat Password'
                                      }))