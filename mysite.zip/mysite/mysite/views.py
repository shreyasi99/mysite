from django.shortcuts import render

def index_home(request):
    return render(request,'home.html')

def index_about(request):
    return render(request,'about.html')

def index_contacts(request):
    return render(request,'contacts.html')