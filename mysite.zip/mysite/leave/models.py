from django.db import models
from employee.models import addemployee


# Create your models here.

class Leave(models.Model):
    emp = models.ForeignKey(addemployee, on_delete=models.CASCADE)
    satisfaction_leval = models.CharField(max_length=200)
    last_evalution = models.CharField(max_length=200)
    number_project = models.CharField(max_length=200)
    average_monthly_hours = models.CharField(max_length=200)
    time_spend_company = models.CharField(max_length=200)
    work_accident = models.CharField(max_length=200)
    why_left = models.TextField()
    pramotion = models.CharField(max_length=200)
    salary = models.IntegerField()
    sales = models.CharField(max_length=200)

    def __str__(self):
        return self.emp

    # def __str__(self):
    #     return self.satisfaction_leval


class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.description
