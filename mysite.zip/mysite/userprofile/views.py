from django.shortcuts import render
from .models import UserProfile

def user_proile(request):
    profile = UserProfile.objects.get(id=1)
    context={
        'profile':profile
    }
    return render(request,"profile/index.html",context)