from django import forms

from .models import addemployee

class EmpForm(forms.ModelForm):
    class Meta:
        model = addemployee
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(EmpForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'col-md-12'