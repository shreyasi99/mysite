

from django.urls import path

from . import views as emp_views

urlpatterns = [
    path('', emp_views.dashborad, name='dashborad'),
    path('allemp/', emp_views.all_emp, name='all_emp'),
    path('addemp/', emp_views.add_emp, name='addemp'),

    path('update/<int:id>',emp_views.update_emp, name='update_emp'),
    path('delete/<int:id>',emp_views.delete_emp, name='delete_emp'),
    path('view/<int:id>',emp_views.view_emp, name='view_emp'),
]
